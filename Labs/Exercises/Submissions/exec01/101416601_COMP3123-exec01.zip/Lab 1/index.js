console.log("=========================");
console.log("||    COMP 3123 Lab 1  ||");
console.log("==========================");
console.log();
require('./exercise01.js');
require('./exercise02.js');
require('./exercise03.js');
require('./exercise04.js');
