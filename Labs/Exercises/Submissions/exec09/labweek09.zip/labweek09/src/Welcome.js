function Welcome() {
    return <>
        <h1>Welcome to Fullstack Development - I</h1>
        <h2>React JS Programming Week09 Lab exercise</h2>
    </> 
}

export default Welcome;