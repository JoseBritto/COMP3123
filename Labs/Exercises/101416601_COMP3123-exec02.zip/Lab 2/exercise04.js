var values = [1, 60, 34, 30, 20, 5]

const filterLessThan20 = values.filter(x => x < 20);

console.log(filterLessThan20);